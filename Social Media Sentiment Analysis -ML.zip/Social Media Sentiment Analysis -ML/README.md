Project title - Social Media Sentiment Analysis

Team Code- Team 21

Team Members
1.LIKITHA K - 1KS21AI025
2.RASHMI M  - 1NC20CD020

social media are the fundamental assets to accumulate data about individuals' perspective and opinions towards various topics as they go through hours day to day on social medias and share their perspective. In this specialized paper, we show the utilization of sentimental analysis and how to associate with it.

